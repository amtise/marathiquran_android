package marathiquran.marathiquranapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatSpinner;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;


public class MainActivity extends AppCompatActivity {

    AppCompatSpinner surat_spinner,ayat_spinner;
    SqlLiteDbHelper dbHelper;
    List<Surat> suratList;
    List<Ayat> ayatList;
    int surat_number,surat_id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        surat_spinner = findViewById(R.id.surat_spinner);
        suratList = new ArrayList<>();
        suratList.clear();
        dbHelper = new SqlLiteDbHelper(this);
        dbHelper.openDataBase();
        suratList = dbHelper.getAllSurat();

        ayat_spinner = findViewById(R.id.ayat_spinner);
        ayatList = new ArrayList<>();
        ayatList.clear();
        ayatList= dbHelper.getAllAyats(1);

        ArrayAdapter<Surat> adapter = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_spinner_dropdown_item, suratList);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        surat_spinner.setAdapter(adapter);

        surat_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                surat_id = suratList.get(i).getId();
                surat_number = suratList.get(i).getSurat_number();
                ayatList.clear();
                ayatList= dbHelper.getAllAyats(surat_id);
                ArrayAdapter<Ayat> adapter2 = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_spinner_dropdown_item, ayatList);
                adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                ayat_spinner.setAdapter(adapter2);

                ArrayList<HashMap<String, String>> userList = dbHelper.GetVachan(surat_id,surat_number);
                ListView lv = findViewById(R.id.vachan_list);
                ListAdapter adapter3 = new SimpleAdapter(MainActivity.this, userList, R.layout.list_row,new String[]{"vachan_version","arabic_text","marathi_text"}, new int[]{R.id.vachan_version,R.id.arabic_text, R.id.marathi_text});
                lv.setAdapter(adapter3);

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        ArrayAdapter<Ayat> adapter2 = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_spinner_dropdown_item, ayatList);
        adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        ayat_spinner.setAdapter(adapter2);

        ArrayList<HashMap<String, String>> userList = dbHelper.GetVachan(1,surat_number);
        ListView lv = findViewById(R.id.vachan_list);
        ListAdapter adapter3 = new SimpleAdapter(MainActivity.this, userList, R.layout.list_row,new String[]{"vachan_version","arabic_text","marathi_text"}, new int[]{R.id.vachan_version,R.id.arabic_text, R.id.marathi_text});
        lv.setAdapter(adapter3);
    }
}
